//
//  ViewController.swift
//  SearchMusic
//
//  Created by SonVu on 10/31/16.
//  Copyright © 2016 SonVu. All rights reserved.
//

import UIKit
import Alamofire
import AVFoundation
import MBProgressHUD

class ViewController: UIViewController, UISearchBarDelegate, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var searchBarView: UISearchBar!
    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var noResultLabel: UILabel!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var toolBarView: UIToolbar!
    @IBOutlet weak var nameToolbarItem: UIButton!
    @IBOutlet weak var playpauseButton: UIButton!
    @IBOutlet weak var nextButton: UIButton!
    @IBOutlet weak var imageToolbarButton: UIButton!
    
    var trackNameArr : [String] = []
    var artistNameArr = [String]()
    var priceArr = [Float]()
    var imagesLinkArr = [String]()
    var previewLinkArr = [String]()
    
    var trackName : String = ""
    var artistName : String = ""
    var price : Float = 0
    var imageLink : String = ""
    var previewLink : String = ""
    
    var player = AVPlayer()
    
    var currenIndex : Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        self.trackNameArr.removeAll()
        self.artistNameArr.removeAll()
        self.priceArr.removeAll()
        self.imagesLinkArr.removeAll()
        self.previewLink.removeAll()
        
        self.toolBarView.isHidden = true
        self.tableView.isHidden = true
        self.noResultLabel.isHidden = true
        self.searchBarView.delegate = self
        self.tableView.delegate = self
        self.tableView.dataSource = self
        
        loadImage()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK: PLAY PAUSE MUSIC
    @IBAction func pauseMusic(_ sender: Any) {
        if player.rate == 1.0 {
            player.pause()
            playpauseButton.setBackgroundImage(UIImage(named: "Play-50"), for: .normal)
        } else {
            playpauseButton.setBackgroundImage(UIImage(named: "Pause-50"), for: .normal)
            player.play()
        }
    }
    
    
    //MARK: NEXT MUSIC
    @IBAction func nextmusic(_ sender: Any) {
        self.currenIndex += 1
        if self.currenIndex > self.previewLinkArr.count - 1 {
            self.currenIndex = self.previewLinkArr.startIndex
        }
        let nexturl = self.previewLinkArr[self.currenIndex]
        let trackname = self.trackNameArr[self.currenIndex]
        let imgUrl = URL(string: self.imagesLinkArr[self.currenIndex])
        
        let playerItem = AVPlayerItem(url: URL(string: nexturl)!)
        
        
        self.nameToolbarItem.setTitle(trackname, for: .normal)
        let data = NSData(contentsOf: imgUrl!)
        let image = UIImage(data: data as! Data)
        self.imageToolbarButton.setBackgroundImage(image, for: .normal)
        player = AVPlayer(playerItem: playerItem)
        player.rate = 1.0
        player.play()
        
        
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.trackNameArr.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SongCell", for: indexPath)
        let imageLabel = cell.contentView.viewWithTag(200)! as! UIImageView
        let nameLabel = cell.contentView.viewWithTag(100) as! UILabel
        let infoLabel = cell.contentView.viewWithTag(50) as! UILabel
        let priceLabel = cell.contentView.viewWithTag(20) as! UIButton
        nameLabel.text = self.trackNameArr[indexPath.row]
        infoLabel.text = self.artistNameArr[indexPath.row]
        priceLabel.setTitle(" $ \(String(self.priceArr[indexPath.row])) ", for: .normal)
        priceLabel.layer.borderWidth = 1
        priceLabel.layer.cornerRadius = 5
        priceLabel.layer.borderColor = UIColor.blue.cgColor
        let url = URL(string: self.imagesLinkArr[indexPath.row])
        imageLabel.sd_setImage(with: url)
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    
    //MARK: DID SELECT
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("INDEX: \(indexPath.row)")
        self.currenIndex = indexPath.row
        print("CURRENT INDEX: \(self.currenIndex)")
        let url = self.previewLinkArr[indexPath.row]
        let playerItem = AVPlayerItem(url: URL(string: url)!)
        player = AVPlayer(playerItem: playerItem)
        player.rate = 1.0
        player.play()
        playpauseButton.setBackgroundImage(UIImage(named: "Pause-50"), for: .normal)
        nextButton.setBackgroundImage(UIImage(named: "Fast Forward-50"), for: .normal)
        
        self.toolBarView.isHidden = false
        
        let imageurl = URL(string: self.imagesLinkArr[indexPath.row])
        let trackname = self.trackNameArr[indexPath.row]
        
        let data = NSData(contentsOf: imageurl!)
        let image = UIImage(data: data as! Data)
        self.imageToolbarButton.setBackgroundImage(image, for: .normal)
        
        self.nameToolbarItem.setTitle(trackname, for: .normal)
        
    }
    
    
    //MARK: EVENT_SearchbarClicked
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        self.view.endEditing(true)
        if searchBar.text != "" {
            self.trackNameArr.removeAll()
            self.artistNameArr.removeAll()
            self.priceArr.removeAll()
            self.imagesLinkArr.removeAll()
            self.previewLinkArr.removeAll()
            
            DispatchQueue.main.async {
                self.requestItunesSong(song: searchBar.text!)
                let spin = MBProgressHUD.showAdded(to: self.view, animated: true)
                spin.label.text = "Loading"
                spin.detailsLabel.text = "Please Wait"
                spin.hide(animated: true, afterDelay: 2)
                
            }
            imageView.isHidden = true
            label.isHidden = true
            tableView.isHidden = false
        }
    }
    
    //MARK: LOAD IMAGE
    func loadImage()  {
        let urlImage = URL(string: "http://www.androidpolice.com/wp-content/uploads/2015/09/nexus2cee_image10.png");
        self.imageView.sd_setImage(with: urlImage)
    }
    
    //MARK: SEARCH SONGS
    func requestItunesSong(song : String) {
        var newSong : String = ""
        newSong = song.replacingOccurrences(of: " ", with: "+")
        print("NEW SONG: \(newSong)")
        Alamofire.request("https://itunes.apple.com/search?term=\(newSong)").responseJSON { response in
            //print(response.request)  // original URL request
            //print(response.response) // HTTP URL response
            //print(response.data)     // server data
            //print(response.result)   // result of response serialization
            
            guard let json = response.result.value as? [String : AnyObject] else {
                return
            }
            guard let result = json["results"] as? [AnyObject] else {
                return
            }
            for i in 0..<8 {
                guard let resultbyIndex = result[i] as? [String : AnyObject] else {
                    return
                }
                guard let kind = resultbyIndex["kind"] as? String else {
                    return
                }
                if kind == "song" {
                    guard let trackName = resultbyIndex["trackName"]  as? String else {
                        return
                    }
                    self.trackName = trackName
                    self.trackNameArr.append(self.trackName)
                    self.tableView.reloadData()
                    
                    guard let artistName = resultbyIndex["artistName"] as? String else {
                        return
                    }
                    self.artistName = artistName
                    self.artistNameArr.append(self.artistName)
                    self.tableView.reloadData()
                    
                    guard let price = resultbyIndex["trackPrice"] as? Float else {
                        return
                    }
                    self.price = price
                    self.priceArr.append(self.price)
                    self.tableView.reloadData()
                    
                    guard let image = resultbyIndex["artworkUrl30"] as? String else {
                        return
                    }
                    self.imageLink = image
                    self.imagesLinkArr.append(self.imageLink)
                    self.tableView.reloadData()
                    
                    guard let preview = resultbyIndex["previewUrl"] as? String else {
                        return
                    }
                    self.previewLink = preview
                    self.previewLinkArr.append(self.previewLink)
                    self.tableView.reloadData()
                    
                }
            }
        }
    }
    
}
